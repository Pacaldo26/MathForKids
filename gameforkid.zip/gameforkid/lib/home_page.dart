import 'dart:math';
import 'package:flutter/material.dart';
import 'package:gameforkid/const.dart';
import 'package:gameforkid/util/my_buttons.dart';
import 'package:gameforkid/util/result_message.dart';

class HomePage extends StatefulWidget{
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  // number of pad
  List<String> numberPad = [
    '7',
    '8',
    '9',
    'C',
    '4',
    '5',
    '6',
    'DEL',
    '1',
    '2',
    '3',
    '=',
    '0',
  ];

  // number a and number b
  int numberA = 1;
  int numberB = 1;

  //user answer
  String userAnswer = '';

  //user tap the button
  void buttonTapped(String button){
    setState(() {
        if (button == '=') {
          checkResult();
        }
        
        else if (button == 'C') {
        userAnswer = '';
      } else if (button == 'DEL') {
        // delete the number
        if (userAnswer.isNotEmpty) {
           userAnswer = userAnswer.substring(0, userAnswer.length - 1);
        }
      } else if (userAnswer.length < 3) {
        // maximum input 3
        userAnswer += button;
      } 
    });
  }

  // CHECK IF THE USER CORRECT OR NOT
  void checkResult() {
    if (numberA + numberB == int.parse(userAnswer)) {
      showDialog(context: context, builder: (context) {
        return ResultMessage(message: 'Correct', onTap: goToNextQuestion, icon: Icons.arrow_forward,);
      });
    } else {
      showDialog(context: context, builder: (context) {
        return ResultMessage(message: 'Incorrect', onTap: goBackToQuestion, icon: Icons.rotate_left,);
      });
    }
  }

  //create a random number
  var randomNumber = Random();

  //go to  next question
  void goToNextQuestion() {
    // dismiss the alert dialog
    Navigator.of(context).pop();

    // reset the values
    setState(() {
      userAnswer = '';
    });

    // create a new question
    numberA = randomNumber.nextInt(10);
    numberB = randomNumber.nextInt(10);
  }
    //go back to the question
    void goBackToQuestion() {
      //dismiss alert dialog
      Navigator.of(context).pop();
    }


  


  @override 
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurple[300],
      body: Column(
        children: [
          //level progress, player needs 5 correct answers in a row to proceed to next level
          Container( child: Text("Math for Kids"),
            height: 160,
            color: Colors.deepPurple,
          ),
          //question
          Expanded(
            child: Container(
              child: Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // question
                    Text(
                      numberA.toString() + '+' + numberB.toString() + '=',
                    style: whiteTextStyle,
                    ),
                    // answer
                    Container(
                      height: 50,
                      width: 150,
                      decoration: BoxDecoration(
                        color: Colors.deepPurple[400],
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Center(
                        child: Text(
                          userAnswer, style: whiteTextStyle,
                        ),
                      ),
                    ),
                  ],
                ),
            ),
          ),
        ),
          //number of pad
          Expanded(
            flex: 2,
            child: Container(
              child: Padding(
                padding: const EdgeInsets.all(4.0),
                child: GridView.builder(
                  itemCount: numberPad.length,
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 4,
                ), 
                itemBuilder: (context, index){
                  return MyButton(
                    child: numberPad[index],
                    onTap: () => buttonTapped(numberPad[index]),
                  );
                },
                            ),
              ),
           ),
          ),
        ],
      ),
    );
  }
}