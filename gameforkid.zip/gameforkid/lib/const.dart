import 'package:flutter/material.dart';

var whiteTextStyle = const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 24,
                  color: Colors.white,
                );