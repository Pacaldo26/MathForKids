package com.example.gameforkid

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
